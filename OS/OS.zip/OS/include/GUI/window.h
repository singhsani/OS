#ifndef __OS__GUI__WINDOW_H
#define __OS__GUI__WINDOW_H
namespace OS{
    namespace gui{
    }
}

#endif

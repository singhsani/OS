#ifndef __OS_COMMON__GRAPHICSCONTEXT_H
#define __OS_COMMON__GRAPHICSCONTEXT_H
#include <drivers/vga.h>S
namespace OS{
    namespace common{
        typedef GraphicsContext VedioGraphicArray;
    }
}

#endif

#include<gui/widget.h>
using namespace OS::common;
using namespace OS::gui;

Widget::Widget(Widget* parent,OS::common::uint32_t x,OS::common::uint32_t y,OS::common::uint32_t w,OS::common::uint32_t h,OS::common::uint8_t r,OS::common::uint8_t g,OS::common::uint8_t b){
    this->parent=parent;
    this->x=x;
    this->y=y;
    this->w=w;
    this->h=h;
    this->r=r;
    this->g=g;
    this->b=b;
    this->focusable=true;
}
            
Widget::~Widget(){
}
            
void Widget::GetFocuse(Widget* widget){
    if(parent!=0)
        parent->GetFocuse(widget);
    
}
void Widget::ModelToScreen(uint32_t &x,uint32_t &y){
    if(parent!=0)
        parent->ModelToScreen(x,y);
    x+=this->x;
    y+=this->y;
}
void Widget::Draw(GraphicContext* gc){
    int X=0;
    int Y=0;
    ModelToScreen(X,Y);
    gc->FillRectangle(X,Y,w,h,r,g,b);
    
}
void Widget::OnMouseDown(uint32_t x,uint32_t y){
    if(focusable)
        GetFocuse(this);
}
void Widget::OnMouseUp(uint32_t x,uint32_t y){
    
}
void Widget::OnMouseMove(uint32_t oldx,uint32_t oldy,uint32_t newx,uint32_t newy){
    
}
            
void Widget::OnKeyDown(uint32_t x,uint32_t y){
    
}
void Widget::OnKeyUp(uint32_t x,uint32_t y){
    
}
